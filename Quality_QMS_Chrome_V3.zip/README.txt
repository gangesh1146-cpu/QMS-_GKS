QUALITY QMS CHROME APP - VERSION 3

Open index.html in Chrome and use Add to Home screen when available.

V3 includes:
- Customer Complaint
- Internal Rejection
- Supplier Rejection
- NC / Process Issue
- 5 Why and Root Cause
- CAPA and closure
- Photo capture/upload
- Automatic record numbering
- Edit records
- Search and filter
- Dashboard with defect and monthly summaries
- CSV-compatible reporting via browser data
- JSON backup and restore

Data is stored locally in Chrome on the phone. Keep backups and do not clear Chrome site data.
